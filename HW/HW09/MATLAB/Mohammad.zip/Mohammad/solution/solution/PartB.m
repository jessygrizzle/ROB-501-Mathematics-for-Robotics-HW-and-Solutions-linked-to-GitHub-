

function dfdx = PartB(X)

syms x1 x2 x3 f

f =  3*x1*(2*x2-x3^3) + (x2^4)/3 ;

delta = [0.01 0.005 0.005] ;

dfdx1 = (subs(f,[x1 x2 x3],[X(1)+delta(1)  X(2)  X(3)]) - subs(f,[x1 x2 x3],[X(1)-delta(1)  X(2)  X(3)]) )./2./delta(1) ;

dfdx2 = (subs(f,[x1 x2 x3],[X(1)  X(2)+delta(2)  X(3)]) - subs(f,[x1 x2 x3],[X(1)  X(2)-delta(2)  X(3)]) )./2./delta(2) ;

dfdx3 = (subs(f,[x1 x2 x3],[X(1)  X(2)  X(3)+delta(3)]) - subs(f,[x1 x2 x3],[X(1)  X(2)  X(3)-delta(3)]) )./2./delta(3) ;

dfdx = [dfdx1 dfdx2 dfdx3] ;