
function f=funcPartC(x)
if length(x)~=5
    'Dimension of x is not equal t0 5'
    return
end

x1=x(1);
x2=x(2);
x3=x(3);
x4=x(4);
x5=x(5);
%
f =  (x4/2-x2/3+1.5).^3.*(sin(42.6*x1-21*x2 + pi/2)).*exp(0.15*sin(4*x3-3*x2-x5)) +...
    (4*(x1./3+.2).*sin(39.4*x3-11.5*x1)).*(exp(0.7*cos(7*x2+x5-x3))).^4 ;