

function dfdx = PartC(X)

if length(X)~=5
    'Dimension of x is not equal t0 5'
    return
end

delta = [0.001 0.001 0.001 0.005 0.005] ;

dfdx1 = (funcPartC([X(1)+delta(1) X(2) X(3) X(4) X(5)]) - funcPartC([X(1)-delta(1) X(2) X(3) X(4) X(5)]) )./2./delta(1) ;

dfdx2 = (funcPartC([X(1) X(2)+delta(2) X(3) X(4) X(5)]) - funcPartC([X(1) X(2)-delta(2) X(3) X(4) X(5)]) )./2./delta(2) ;

dfdx3 = (funcPartC([X(1) X(2) X(3)+delta(3) X(4) X(5)]) - funcPartC([X(1) X(2) X(3)-delta(3) X(4) X(5)]) )./2./delta(3) ;

dfdx4 = (funcPartC([X(1) X(2) X(3) X(4)+delta(4) X(5)]) - funcPartC([X(1) X(2) X(3) X(4)-delta(4) X(5)]) )./2./delta(4) ;

dfdx5 = (funcPartC([X(1) X(2) X(3) X(4) X(5)+delta(5)]) - funcPartC([X(1) X(2) X(3) X(4) X(5)-delta(5)]) )./2./delta(5) ;

     dfdx = [dfdx1 dfdx2 dfdx3 dfdx4 dfdx5] ;